E:\wamp64\www\weblogicmvc\wlstudio\view\home\index.haanga
E:\wamp64\www\weblogicmvc\wlstudio\view\layout\layout.haanga
