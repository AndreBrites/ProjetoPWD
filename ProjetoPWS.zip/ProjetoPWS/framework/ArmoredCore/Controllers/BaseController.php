<?php

namespace ArmoredCore\Controllers;
/**
 * Created by PhpStorm.
 * User: smendes
 * Date: 09-05-2016
 * Time: 11:34
 */
class BaseController
{

}