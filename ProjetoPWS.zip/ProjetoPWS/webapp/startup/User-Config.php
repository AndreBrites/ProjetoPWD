<?php
/**
 * Created by PhpStorm.
 * User: smendes
 * Date: 07-04-2017
 * Time: 18:02
 */

define('WL_SERVER_URL',                         'http://localhost/');
define('WL_SERVER_MOD_NAME',                    'webapp');
define('WL_SERVER_PUBLIC_DIR_NAME',             'public');
define('WL_RUNNING_ENV',                        'dev');
define('WL_DEBUG_ENABLED',                      true);

$defaultDbConnection = array (
    'DBMS'          => 'mysql',
    'SERVER'        => 'localhost',
    'DATABASENAME'  => 'webapp',
    'USER'          => 'root',
    'PASSWORD'      => ''
);