<?php
/**
 * Created by PhpStorm.
 * User: smendes
 * Date: 17-04-2017
 * Time: 17:45
 */

// attach composer registry
require WL_VENDOR_BASE_DIR . '\\autoload.php';


$psr4vendorMap = [
    'Stolz',
    'Symfony',
    'Tracy',
    'Pd',
    'PetrKnap',
    'Netpromotion',
    'Hoa',
    'Kdyby',
    'Nette',
    'Filisko',
    'Windwalker'
];